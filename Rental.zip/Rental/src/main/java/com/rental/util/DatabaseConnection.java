package com.rental.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatabaseConnection {
    private static final Logger LOGGER = Logger.getLogger(DatabaseConnection.class.getName());
    private static final String JDBC_URL = "jdbc:sqlite:rental.db";

    public static Connection connect() {
        try {
            return DriverManager.getConnection(JDBC_URL);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to connect to database", e);
            throw new RuntimeException("Database connection failed", e);
        }
    }

    public static boolean testConnection() {
        try (Connection conn = connect()) {
            return !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}