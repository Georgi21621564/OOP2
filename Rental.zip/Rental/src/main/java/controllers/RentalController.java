package controllers;

import dao.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import models.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.sql.SQLException;

public class RentalController {
    @FXML private ComboBox<Car> carComboBox;
    @FXML private ComboBox<Client> clientComboBox;
    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;

    private final CarDAO carDAO = new CarDAO();
    private final ClientDAO clientDAO = new ClientDAO();
    private final RentalDAO rentalDAO = new RentalDAO();

    @FXML
    public void initialize() {
        carComboBox.setItems(carDAO.getAvailableCars());
        clientComboBox.setItems(clientDAO.getAllClients());
    }

    @FXML
    private void handleRent() {
        try {
            if (validateInput()) {
                LocalDate start = startDatePicker.getValue();
                LocalDate end = endDatePicker.getValue();
                Car car = carComboBox.getValue();
                Client client = clientComboBox.getValue();

                long days = ChronoUnit.DAYS.between(start, end);
                double price = days * car.getPricePerDay();

                Rental rental = new Rental(
                        car.getId(),
                        client.getId(),
                        start,
                        end,
                        price
                );

                rentalDAO.createRental(rental);
                car.setAvailable(false);
                carDAO.updateCar(car);
                clearForm();
            }
        } catch (SQLException e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    private boolean validateInput() {
        if (carComboBox.getValue() == null || clientComboBox.getValue() == null ||
                startDatePicker.getValue() == null || endDatePicker.getValue() == null) {
            showAlert("All fields are required");
            return false;
        }
        if (startDatePicker.getValue().isAfter(endDatePicker.getValue())) {
            showAlert("End date must be after start date");
            return false;
        }
        return true;
    }

    private void clearForm() {
        carComboBox.getSelectionModel().clearSelection();
        clientComboBox.getSelectionModel().clearSelection();
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
        carComboBox.setItems(carDAO.getAvailableCars());
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText(message);
        alert.showAndWait();
    }
}