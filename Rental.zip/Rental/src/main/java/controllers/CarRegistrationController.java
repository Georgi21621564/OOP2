package controllers;

import dao.CarDAO;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import models.Car;

import java.sql.SQLException;

public class CarRegistrationController extends BaseController {
    @FXML private ComboBox<String> classComboBox;
    @FXML private ComboBox<String> categoryComboBox;
    @FXML private TextField makeField;
    @FXML private TextField modelField;
    private final CarDAO carDAO = new CarDAO();

    @FXML
    public void initialize() {
        classComboBox.getItems().addAll("Luxury", "Family", "City");
        categoryComboBox.getItems().addAll("Sedan", "SUV", "Convertible");
    }

    @FXML
    public void handleRegisterCar() {
        Car car = new Car();
        car.setCarClass(classComboBox.getValue());
        car.setCategory(categoryComboBox.getValue());
        car.setMake(makeField.getText());
        car.setModel(modelField.getText());

        try {
            carDAO.createCar(car);
        } catch (SQLException e) {
            showAlert("Error", "Failed to register car");
        }
    }
}