package controllers;

import javafx.event.ActionEvent;

import java.io.IOException;

public class AdminController extends BaseController {
    // 1. Manage Companies
    public void handleCompanyManagement(ActionEvent event) throws IOException {
        loadFXML("/fxml/company_management.fxml", event);
    }

    // 2. Manage Operators
    public void handleOperatorManagement(ActionEvent event) throws IOException {
        loadFXML("/fxml/operator_management.fxml", event);
    }

    // 3. Register Cars
    public void handleCarRegistration(ActionEvent event) throws IOException {
        loadFXML("/fxml/car_registration.fxml", event);
    }

    // 4. View Available Cars
    public void handleViewCars(ActionEvent event) throws IOException {
        loadFXML("/fxml/car_list.fxml", event);
    }
}