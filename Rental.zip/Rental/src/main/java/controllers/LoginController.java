package controllers;

import dao.UserDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import models.User;

import java.io.IOException;

public class LoginController extends BaseController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    public void handleLogin(ActionEvent event) {
        UserDAO userDAO = new UserDAO();
        User user = userDAO.authenticate(usernameField.getText(), passwordField.getText());

        try {
            if (user != null) {
                if ("admin".equals(user.getRole())) {
                    loadFXML("/fxml/admin_dashboard.fxml", event);
                } else {
                    loadFXML("/fxml/operator_dashboard.fxml", event);
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Failed to load dashboard");
        }
    }
}