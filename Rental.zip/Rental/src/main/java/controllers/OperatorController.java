package controllers;

import javafx.event.ActionEvent;

import java.io.IOException;

public class OperatorController extends BaseController {
    // 1. Manage Clients
    public void handleClientManagement(ActionEvent event) throws IOException {
        loadFXML("/fxml/client_management.fxml", event);
    }
    // 2. Register Cars
    public void handleCarRegistration(ActionEvent event) throws IOException {
        loadFXML("/fxml/car_registration.fxml", event);
    }
    // 3. Rent Car
    public void handleRentCar(ActionEvent event) throws IOException {
        loadFXML("/fxml/rent_car.fxml", event);
    }
    // 4. Return Car
    public void handleReturnCar(ActionEvent event) throws IOException {
        loadFXML("/fxml/return_car.fxml", event);
    }
    // 5. Calculate Price
    public void handleCalculatePrice(ActionEvent event) throws IOException {
        loadFXML("/fxml/price_calculation.fxml", event);
    }

    // 6. View History
    public void handleViewHistory(ActionEvent event) throws IOException {
        loadFXML("/fxml/rental_history.fxml", event);
    }
}