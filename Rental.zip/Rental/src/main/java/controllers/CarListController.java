package controllers;

import dao.CarDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Car;

    public class CarListController {
        @FXML private TableView<Car> carTable;
        private final CarDAO carDAO = new CarDAO();

        public void initializeData() {
            carTable.setItems(carDAO.getAvailableCars());
            setupColumns();
        }

        private void setupColumns() {
            TableColumn<Car, String> makeCol = new TableColumn<>("Make");
            makeCol.setCellValueFactory(new PropertyValueFactory<>("make"));

            TableColumn<Car, String> modelCol = new TableColumn<>("Model");
            modelCol.setCellValueFactory(new PropertyValueFactory<>("model"));

            TableColumn<Car, String> classCol = new TableColumn<>("Class");
            classCol.setCellValueFactory(new PropertyValueFactory<>("carClass"));

            carTable.getColumns().setAll(makeCol, modelCol, classCol);
        }
    }