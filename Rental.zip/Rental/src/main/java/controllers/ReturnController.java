package controllers;

import dao.RentalDAO;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Car;
import models.Rental;
import java.sql.SQLException;
import dao.*;
import javafx.scene.control.*;

public class ReturnController {
    private final RentalDAO rentalDAO = new RentalDAO();
    private final CarDAO carDAO = new CarDAO();
    private Rental selectedRental;

    @FXML private TableView<Rental> rentalsTable;
    @FXML private TableColumn<Rental, Integer> rentalIdColumn;
    @FXML private TextField kilometersField;
    @FXML private TextArea conditionArea;
    @FXML private ComboBox<String> statusComboBox;

    @FXML
    public void initialize() {
        setupTable();
        setupSelectionHandler();
        statusComboBox.getItems().addAll("Good", "Damaged");
    }

    private void setupTable() {
        rentalIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        rentalsTable.getColumns().forEach(col -> col.setStyle("-fx-alignment: CENTER;"));
    }


    private void setupSelectionHandler() {
        rentalsTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    selectedRental = newSelection;
                    if (newSelection != null) {
                        kilometersField.setText(String.valueOf(newSelection.getKilometers()));
                        conditionArea.setText(newSelection.getConditionReport());
                        statusComboBox.setValue(newSelection.getReturnStatus());
                    }
                });
    }

    @FXML
    private void handleProcessReturn() {
        if (selectedRental != null && validateInput()) {
            try {
                // Update rental
                selectedRental.setKilometers(Double.parseDouble(kilometersField.getText()));
                selectedRental.setConditionReport(conditionArea.getText());
                selectedRental.setReturnStatus(statusComboBox.getValue());

                // Update car availability
                Car car = carDAO.getCarById(selectedRental.getCarId());
                car.setAvailable(true);
                carDAO.updateCar(car);

                // Refresh
                clearForm();
            } catch (SQLException | NumberFormatException e) {
                showAlert("Error: " + e.getMessage());
            }
        }
    }

    private boolean validateInput() {
        if (kilometersField.getText().isEmpty() ||
                conditionArea.getText().isEmpty() ||
                statusComboBox.getValue() == null) {

            showAlert("All fields are required");
            return false;
        }
        return true;
    }

    private void clearForm() {
        kilometersField.clear();
        conditionArea.clear();
        statusComboBox.getSelectionModel().clearSelection();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText(message);
        alert.showAndWait();
    }
}