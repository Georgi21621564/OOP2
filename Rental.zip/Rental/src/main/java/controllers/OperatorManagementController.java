package controllers;

import dao.UserDAO;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import jdk.incubator.vector.VectorOperators;
import models.User;
import java.sql.SQLException;
import dao.OperatorDAO;
import models.Operator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class OperatorManagementController {
    private final UserDAO userDAO = new UserDAO();
    private User selectedOperator;

    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private TableView<User> operatorsTable;
    @FXML private TableColumn<User, Integer> idColumn;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, Void> actionsColumn;

    @FXML
    public void initialize() {
        setupTableColumns();
        loadOperators();
        setupTableSelection();
        configureActionsColumn();
    }

    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
    }

    private void loadOperators() {
        ObservableList<User> operators =
                FXCollections.observableArrayList(userDAO.getAllOperators());
        operatorsTable.setItems(operators);
    }

    private void setupTableSelection() {
        operatorsTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    selectedOperator = newSelection;
                    if (newSelection != null) {
                        usernameField.setText(newSelection.getUsername());
                    }
                });
    }
    private void configureActionsColumn() {
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button deleteBtn = new Button("Delete");

            {
                deleteBtn.setOnAction(e -> {
                    User user = getTableView().getItems().get(getIndex());
                    try {
                        userDAO.deleteUser(user.getId());
                    } catch (SQLException ex) {
                        // Хубаво е тука да не хвърляме RunTi
                        throw new RuntimeException(ex);
                    }
                    loadOperators();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : deleteBtn);
            }
        });
    }

    // Хубаво е да се сложи Exception Handling тука ;)
    @FXML
    private void handleAddOperator() throws SQLException {
        if (validateFields()) {
            User user = new User(
            0,
                usernameField.getText().trim(),
                passwordField.getText().trim(),
            "operator"
            );
            userDAO.createUser(user);
            clearFields();
            loadOperators();
        }
    }

    // Хубаво е да се сложи Exception Handling тука ;)
    @FXML
    private void handleDeleteOperator() throws SQLException {
        if (selectedOperator != null) {
            userDAO.deleteUser(selectedOperator.getId());
            clearFields();
            loadOperators();
        } else {
            showAlert("No Selection", "Please select an operator to delete.");
        }
    }

    private boolean validateFields() {
        if (usernameField.getText().isEmpty() || passwordField.getText().isEmpty()) {
            showAlert("Validation Error", "Please fill all fields");
            return false;
        }
        return true;
    }

    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        selectedOperator = null;
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    /*private class ActionsCell extends TableCell<Operator, Void> {
        private final Button deleteButton = new Button("Delete");

        public ActionsCell(TableView<Operator> table) {
            deleteButton.setOnAction(e -> {
                Operator operator = getTableView().getItems().get(getIndex());
                operatorDAO.deleteOperator(operator.getId());
                loadOperators(); // Refresh table
            });
        }

        @Override
        protected void updateItem(Void item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(deleteButton);
            }
        }
    }*/
}