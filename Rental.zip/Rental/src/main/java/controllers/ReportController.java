package controllers;

import dao.RentalDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import models.Rental;
import java.time.LocalDate;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;

public class ReportController {
    private final RentalDAO rentalDAO = new RentalDAO();

    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;
    @FXML private TableView<Rental> reportTable;
    @FXML private TableColumn<Rental, Integer> rentalIdColumn;
    @FXML private TableColumn<Rental, Integer> carIdColumn;
    @FXML private TableColumn<Rental, Integer> clientIdColumn;
    @FXML private TableColumn<Rental, LocalDate> startDateColumn;
    @FXML private TableColumn<Rental, LocalDate> endDateColumn;
    @FXML private TableColumn<Rental, Double> totalPriceColumn;

    @FXML
    public void initialize() {
        configureTableColumns();
    }

    private void configureTableColumns() {
        rentalIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        carIdColumn.setCellValueFactory(new PropertyValueFactory<>("carId"));
        clientIdColumn.setCellValueFactory(new PropertyValueFactory<>("clientId"));
        startDateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        endDateColumn.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        totalPriceColumn.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
    }

    @FXML
    private void handleGenerateReport() {
        LocalDate start = startDatePicker.getValue();
        LocalDate end = endDatePicker.getValue();

        if (!validateDates(start, end)) return;

        reportTable.setItems(rentalDAO.getRentalsByPeriod(start, end));
    }

    private boolean validateDates(LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            showAlert("Missing Dates", "Please select both start and end dates");
            return false;
        }
        if (start.isAfter(end)) {
            showAlert("Invalid Dates", "Start date must be before end date");
            return false;
        }
        return true;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}