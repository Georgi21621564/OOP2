package controllers;

import dao.CompanyDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import models.Company;

import java.sql.SQLException;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;

public class CompanyController {
    private final CompanyDAO companyDAO = new CompanyDAO();
    private Company selectedCompany;

    @FXML private TextField nameField;
    @FXML private TextField addressField;
    @FXML private TableView<Company> companiesTable;
    @FXML private TableColumn<Company, Integer> idColumn;
    @FXML private TableColumn<Company, String> nameColumn;
    @FXML private TableColumn<Company, String> addressColumn;
    @FXML private TableColumn<Company, Void> actionsColumn;

    @FXML
    public void initialize() {
        setupTableColumns();
        loadCompanies();
        setupTableSelection();
        configureActionsColumn();
    }

    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
    }

    private void loadCompanies() {
        ObservableList<Company> companies = companyDAO.getAllCompanies();
        companiesTable.setItems(companies);
    }

    private void setupTableSelection() {
        companiesTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    selectedCompany = newSelection;
                    if (newSelection != null) {
                        nameField.setText(newSelection.getName());
                        addressField.setText(newSelection.getAddress());
                    }
                });
    }

    private void configureActionsColumn() {
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button deleteBtn = new Button("Delete");

            {
                deleteBtn.setOnAction(e -> {
                    Company company = getTableView().getItems().get(getIndex());
                    try {
                        companyDAO.deleteCompany(company.getId());
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                    loadCompanies();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : deleteBtn);
            }
        });
    }

    @FXML
    private void handleAddCompany() throws SQLException {
        if (validateFields()) {
            Company company = new Company(
                    0, // ID will be auto-generated
                    nameField.getText().trim(),
                    addressField.getText().trim()
            );
            companyDAO.createCompany(company);
            clearFields();
            loadCompanies();
        }
    }

    private boolean validateFields() {
        if (nameField.getText().isEmpty() || addressField.getText().isEmpty()) {
            showAlert("Validation Error", "Please fill all fields");
            return false;
        }
        return true;
    }

    private void clearFields() {
        nameField.clear();
        addressField.clear();
        selectedCompany = null;
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}