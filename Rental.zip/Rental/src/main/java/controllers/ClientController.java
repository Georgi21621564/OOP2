package controllers;

import dao.ClientDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import models.Client;
import java.sql.SQLException;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ClientController {
    private final ClientDAO clientDAO = new ClientDAO();
    private Client selectedClient;

    @FXML private TextField fullNameField;
    @FXML private TextField emailField;
    @FXML private TextField phoneField;
    @FXML private TableView<Client> clientsTable;
    @FXML private TableColumn<Client, Integer> idColumn;
    @FXML private TableColumn<Client, String> fullNameColumn;
    @FXML private TableColumn<Client, String> emailColumn;
    @FXML private TableColumn<Client, String> phoneColumn;
    @FXML private TableColumn<Client, Void> actionsColumn;

    @FXML
    public void initialize() {
        setupTableColumns();
        loadClients();
        setupTableSelection();
        configureActionsColumn();
    }

    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
    }

    private void loadClients() {
        ObservableList<Client> clients = FXCollections.observableArrayList(clientDAO.getAllClients());
        clientsTable.setItems(clients);
    }

    private void setupTableSelection() {
        clientsTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    selectedClient = newSelection;
                    if (newSelection != null) {
                        fullNameField.setText(newSelection.getFullName());
                        emailField.setText(newSelection.getEmail());
                        phoneField.setText(newSelection.getPhone());
                    }
                });
    }

    private void configureActionsColumn() {
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button deleteBtn = new Button("Delete");

            {
                deleteBtn.setOnAction(e -> {
                    Client client = getTableView().getItems().get(getIndex());
                    try {
                        clientDAO.deleteClient(client.getId());
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                    loadClients();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : deleteBtn);
            }
        });
    }

    @FXML
    private void handleAddClient() throws SQLException {
        if (validateFields()) {
            Client client = new Client(
                    0,
                    fullNameField.getText().trim(),
                    emailField.getText().trim(),
                    phoneField.getText().trim()
            );
            clientDAO.createClient(client);
            clearFields();
            loadClients();
        }
    }

    private boolean validateFields() {
        if (fullNameField.getText().isEmpty() ||
                emailField.getText().isEmpty() ||
                phoneField.getText().isEmpty()) {
            showAlert("Validation Error", "Please fill all fields");
            return false;
        }
        return true;
    }

    private void clearFields() {
        fullNameField.clear();
        emailField.clear();
        phoneField.clear();
        selectedClient = null;
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}