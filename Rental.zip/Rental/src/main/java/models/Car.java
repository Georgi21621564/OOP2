package models;

public class Car {
    private int id;
    private int companyId;
    private String make;
    private String model;
    private String carClass;
    private String category;
    private boolean smokingAllowed;
    private double pricePerDay;
    private double pricePerKm;
    private boolean available;

    public Car() {
    }

    // Only required getters/setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCompanyId() { return companyId; }
    public void setCompanyId(int companyId) { this.companyId = companyId; }
    public String getMake() { return make; }
    public void setMake(String make) { this.make = make; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public String getCarClass() { return carClass; }
    public void setCarClass(String carClass) { this.carClass = carClass; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public boolean isSmokingAllowed() { return smokingAllowed; }
    public void setSmokingAllowed(boolean smokingAllowed) { this.smokingAllowed = smokingAllowed; }
    public double getPricePerDay() { return pricePerDay; }
    public void setPricePerDay(double pricePerDay) { this.pricePerDay = pricePerDay; }
    public double getPricePerKm() { return pricePerKm; }
    public void setPricePerKm(double pricePerKm) { this.pricePerKm = pricePerKm; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}