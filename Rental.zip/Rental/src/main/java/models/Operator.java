package models;
import javafx.beans.property.*;

public class Operator {
    private final IntegerProperty id;
    private final StringProperty username;
    private final StringProperty email;

    public Operator(int id, String username, String email) {
        this.id = new SimpleIntegerProperty(id);
        this.username = new SimpleStringProperty(username);
        this.email = new SimpleStringProperty(email);
    }

    // Getters
    public int getId() { return id.get(); }
    public String getUsername() { return username.get(); }
    public String getEmail() { return email.get(); }

    // Property getters
    public IntegerProperty idProperty() { return id; }
    public StringProperty usernameProperty() { return username; }
    public StringProperty emailProperty() { return email; }

    // Setters
    public void setUsername(String username) { this.username.set(username); }
    public void setEmail(String email) { this.email.set(email); }
}