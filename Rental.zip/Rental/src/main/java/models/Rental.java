package models;

import java.time.LocalDate;

public class Rental {
    private int id;
    private int carId;
    private int clientId;
    private LocalDate startDate;
    private LocalDate endDate;
    private double totalPrice;
    private double kilometers;
    private String conditionReport;
    private String returnStatus;

    // Constructor for new rentals
    public Rental(int carId, int clientId, LocalDate startDate, LocalDate endDate, double totalPrice) {
        this.carId = carId;
        this.clientId = clientId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalPrice = totalPrice;
        this.kilometers = 0;
        this.conditionReport = "";
        this.returnStatus = "active";
    }

    // Full constructor
    public Rental(int id, int carId, int clientId, LocalDate startDate, LocalDate endDate,
                  double totalPrice, double kilometers, String conditionReport, String returnStatus) {
        this(carId, clientId, startDate, endDate, totalPrice);
        this.id = id;
        this.kilometers = kilometers;
        this.conditionReport = conditionReport;
        this.returnStatus = returnStatus;
    }

    // Getters and Setters
    public int getId() { return id; }
    public int getCarId() { return carId; }
    public int getClientId() { return clientId; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public double getTotalPrice() { return totalPrice; }
    public double getKilometers() { return kilometers; }
    public String getConditionReport() { return conditionReport; }
    public String getReturnStatus() { return returnStatus; }
    public void setKilometers(double kilometers) { this.kilometers = kilometers; }
    public void setConditionReport(String conditionReport) { this.conditionReport = conditionReport; }
    public void setReturnStatus(String returnStatus) { this.returnStatus = returnStatus; }
}