package dao;

import com.rental.util.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Rental;
import java.sql.*;
import java.time.LocalDate;

public class RentalDAO {
    private static final String URL = "jdbc:sqlite:rental.db";

    public void createRental(Rental rental) throws SQLException {
        String sql = "INSERT INTO rentals (car_id, client_id, start_date, end_date, total_price) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, rental.getCarId());
            pstmt.setInt(2, rental.getClientId());
            pstmt.setDate(3, Date.valueOf(rental.getStartDate()));
            pstmt.setDate(4, Date.valueOf(rental.getEndDate()));
            pstmt.setDouble(5, rental.getTotalPrice());
            pstmt.executeUpdate();
        }
    }

    public ObservableList<Rental> getRentalsByPeriod(LocalDate start, LocalDate end) {
        ObservableList<Rental> rentals = FXCollections.observableArrayList();
        String sql = "SELECT * FROM rentals WHERE start_date >= ? AND end_date <= ?";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDate(1, Date.valueOf(start));
            pstmt.setDate(2, Date.valueOf(end));

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                rentals.add(new Rental(
                        rs.getInt("id"),
                        rs.getInt("car_id"),
                        rs.getInt("client_id"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getDate("end_date").toLocalDate(),
                        rs.getDouble("total_price"),
                        rs.getDouble("kilometers"),
                        rs.getString("condition_report"),
                        rs.getString("return_status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }

}