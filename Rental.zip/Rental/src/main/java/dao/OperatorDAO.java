package dao;

import models.Operator;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OperatorDAO {
    private static final String URL = "jdbc:sqlite:rental.db";

    public OperatorDAO() {
        createTable();
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS operators (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT NOT NULL UNIQUE," +
                "email TEXT NOT NULL)";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error creating operators table: " + e.getMessage());
        }
    }

    public void addOperator(Operator operator) {
        String sql = "INSERT INTO operators(username, email) VALUES(?,?)";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, operator.getUsername());
            pstmt.setString(2, operator.getEmail());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding operator: " + e.getMessage());
        }
    }

    public List<Operator> getAllOperators() {
        List<Operator> operators = new ArrayList<>();
        String sql = "SELECT * FROM operators";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                operators.add(new Operator(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("email")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting operators: " + e.getMessage());
        }
        return operators;
    }

    public void updateOperator(Operator operator) {
        String sql = "UPDATE operators SET username = ?, email = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, operator.getUsername());
            pstmt.setString(2, operator.getEmail());
            pstmt.setInt(3, operator.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating operator: " + e.getMessage());
        }
    }

    public void deleteOperator(int id) {
        String sql = "DELETE FROM operators WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting operator: " + e.getMessage());
        }
    }
}