package dao;

import com.rental.util.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Company;
import java.sql.*;

public class CompanyDAO {
    public ObservableList<Company> getAllCompanies() {
        ObservableList<Company> companies = FXCollections.observableArrayList();
        String sql = "SELECT * FROM companies";

        try (Connection conn = DatabaseConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Company company = new Company(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("address")
                );
                companies.add(company);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return companies;
    }

    public void deleteCompany(int companyId) throws SQLException {
        String sql = "DELETE FROM companies WHERE id = ?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, companyId);
            pstmt.executeUpdate();
        }
    }

    public void createCompany(Company company) throws SQLException {
        String sql = "INSERT INTO companies (name, address) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, company.getName());
            pstmt.setString(2, company.getAddress());
            pstmt.executeUpdate();
        }
    }
}