package dao;

import com.rental.util.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Client;
import java.sql.*;

    public class ClientDAO {
        public ObservableList<Client> getAllClients() {
            ObservableList<Client> clients = FXCollections.observableArrayList();
            String sql = "SELECT * FROM clients";

            try (Connection conn = DatabaseConnection.connect();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                while (rs.next()) {
                    Client client = new Client();
                    client.setId(rs.getInt("id"));
                    client.setFullName(rs.getString("full_name"));
                    client.setEmail(rs.getString("email"));
                    client.setPhone(rs.getString("phone"));
                    clients.add(client);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return clients;
        }

        public void deleteClient(int clientId) throws SQLException {
            String sql = "DELETE FROM clients WHERE id = ?";
            try (Connection conn = DatabaseConnection.connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, clientId);
                pstmt.executeUpdate();
            }
        }

        public void createClient(Client client) throws SQLException {
            String sql = "INSERT INTO clients (full_name, email, phone) VALUES (?, ?, ?)";
            try (Connection conn = DatabaseConnection.connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, client.getFullName());
                pstmt.setString(2, client.getEmail());
                pstmt.setString(3, client.getPhone());
                pstmt.executeUpdate();
            }
        }
    }