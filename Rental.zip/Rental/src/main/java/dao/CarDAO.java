package dao;

import com.rental.util.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Car;
import java.sql.*;

public class CarDAO {
    public ObservableList<Car> getAvailableCars() {
        ObservableList<Car> cars = FXCollections.observableArrayList();
        String sql = "SELECT * FROM cars WHERE available = 1";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                cars.add(mapResultSetToCar(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cars;
    }

    public void createCar(Car car) throws SQLException {
        String sql = "INSERT INTO cars (company_id, make, model, car_class, category, "
                + "smoking_allowed, price_per_day, price_per_km, available) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, car.getCompanyId());
            pstmt.setString(2, car.getMake());
            pstmt.setString(3, car.getModel());
            pstmt.setString(4, car.getCarClass());
            pstmt.setString(5, car.getCategory());
            pstmt.setBoolean(6, car.isSmokingAllowed());
            pstmt.setDouble(7, car.getPricePerDay());
            pstmt.setDouble(8, car.getPricePerKm());
            pstmt.setBoolean(9, car.isAvailable());

            pstmt.executeUpdate();
        }
    }

    private Car mapResultSetToCar(ResultSet rs) throws SQLException {
        Car car = new Car();
        car.setId(rs.getInt("id"));
        car.setCompanyId(rs.getInt("company_id"));
        car.setMake(rs.getString("make"));
        car.setModel(rs.getString("model"));
        car.setCarClass(rs.getString("car_class"));
        car.setCategory(rs.getString("category"));
        car.setSmokingAllowed(rs.getBoolean("smoking_allowed"));
        car.setPricePerDay(rs.getDouble("price_per_day"));
        car.setPricePerKm(rs.getDouble("price_per_km"));
        car.setAvailable(rs.getBoolean("available"));
        return car;
    }
    public void updateCar(Car car) throws SQLException {
        String sql = "UPDATE cars SET available = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, car.isAvailable());
            pstmt.setInt(2, car.getId());
            pstmt.executeUpdate();
        }
    }
    public Car getCarById(int id) throws SQLException {
        String sql = "SELECT * FROM cars WHERE id = ?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Car(
                );
            }
        }
        return null;
    }
}