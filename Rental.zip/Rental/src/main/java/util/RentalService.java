package util;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class RentalService {
    public double calculatePrice(LocalDate start, LocalDate end, double pricePerDay,
                                 double kilometers, double pricePerKm, String condition) {
        long days = ChronoUnit.DAYS.between(start, end);
        double base = days * pricePerDay;
        double distance = kilometers * pricePerKm;
        double damage = condition.contains("major") ? 500 : (condition.contains("minor") ? 100 : 0);
        return base + distance + damage;
    }
}