module com.rental {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jdk.incubator.vector;

    opens controllers to javafx.fxml;
    opens models to javafx.base;
    exports main.rental;
}